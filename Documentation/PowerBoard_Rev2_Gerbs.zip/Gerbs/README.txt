This is a 4-layer board
The copper layers are as follows from BOTTOM to TOP:
PowerBoard_Hardware-B.Cu_BOTTOMCOPPERLAYER_1.gbr
PowerBoard_Hardware-BM.Cu_BOTTOMMIDDLECOPPERLAYER_2.gbr
PowerBoard_Hardware-UM.Cu_UPPERMIDDLECOPPERLAYER_3.gbr
PowerBoard_Hardware-F.Cu_FRONTCOPPERLAYER_4.gbr